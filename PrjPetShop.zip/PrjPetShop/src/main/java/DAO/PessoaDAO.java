package DAO;

import Objetos.Pessoa;
import Util.Conexao;
import Util.ManipulaData;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PessoaDAO {
    Connection conn;
    ManipulaData md;

    public PessoaDAO() {
        conn = new Conexao().conectar();
        md = new ManipulaData();
    }
    
    public Pessoa salvar(Pessoa p){
        
       try{
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO pessoa(nome, data_nascimento) values(?,?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, p.getNome());
            stmt.setDate(2, md.String2Date(p.getData()));
            stmt.execute();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                p.setIdpessoa(rs.getInt("idpessoa"));
            }
            else{
                p.setIdpessoa(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return p;
    }
    
    public void editar(Pessoa p){
        
        try{
            PreparedStatement stmt = conn.prepareStatement("UPDATE pessoa SET nome = ?, data_nascimento = ?" + "where idpessoa= ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, p.getNome());
            stmt.setDate(2, md.String2Date(p.getData()));
            stmt.setInt(3, p.getIdpessoa());
            stmt.execute();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                p.setIdpessoa(rs.getInt("idpessoa"));
            }
            else{
                p.setIdpessoa(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }
    
    public int excluir(Pessoa p){
        int verif = 0;
        try{
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM pessoa where idpessoa= ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, p.getIdpessoa());
            verif = stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                p.setIdpessoa(rs.getInt("idpessoa"));
            }
            else{
                p.setIdpessoa(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return verif;
    }
    
    public List<Pessoa>getPessoas(){
        List<Pessoa> lstP = new ArrayList();
        
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM pessoa", Statement.RETURN_GENERATED_KEYS);
            
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstP.add(getPessoa(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstP;
    }
    
    public List<Pessoa> getPessoas(Pessoa p){
        
        List<Pessoa> lstP = new ArrayList<>();
        ResultSet rs;
        
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM pessoa where nome ILIKE ?", Statement.RETURN_GENERATED_KEYS);
            ppStmt.setString(1, p.getNome()+ "%");
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstP.add(getPessoa(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstP;
    }
    
    public List<Pessoa> getPessoas(String nome){
        List<Pessoa> lstP = new ArrayList<>();
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM pessoa where nome ILIKE ?");
            ppStmt.setString(1, nome+ "%");
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstP.add(getPessoa(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstP;
    }
    
     public List<Pessoa> getPessoas(String nome, String dataInicio, String dataFim){
        List<Pessoa> lstP = new ArrayList<>();
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM pessoa where nome ILIKE ? and"
                + "data_nascimento BETEWEEN ? and ?");
            ppStmt.setString(1, nome+ "%");
            ppStmt.setDate(2, md.String2Date(dataInicio));
            ppStmt.setDate(3, md.String2Date(dataFim));
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstP.add(getPessoa(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstP;
    }
     
    public List<Pessoa> getPessoas(String dataInicio, String dataFim){
        List<Pessoa> lstP = new ArrayList<>();
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM pessoa where data_nascimento" + "BETEWEEN ? and ?");
            ppStmt.setDate(1, md.String2Date(dataInicio));
            ppStmt.setDate(2, md.String2Date(dataFim));
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstP.add(getPessoa(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstP;
    }
    
    public Pessoa getPessoas(int idpessoa){
        Pessoa p = new Pessoa();
        ResultSet rs;
        
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM pessoa where idpessoa = ?", ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ppStmt.setInt(1, idpessoa);
            rs = ppStmt.executeQuery();
            rs.first();
            p = getPessoa(rs);
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return p;
    }

    private Pessoa getPessoa(ResultSet rs) throws SQLException {
        
        Pessoa p = new Pessoa();
        p.setIdpessoa(rs.getInt("idPessoa"));
        p.setNome(rs.getString("nome"));
        p.setData(md.date2String(rs.getString("data_nascimento")));
        return p;
    }
}
    
