package DAO;

import Objetos.Pet;
import Util.Conexao;
import Util.ManipulaData;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class PetDAO {
    Connection conn;
    ManipulaData md;
    PessoaDAO pDAO;
    
    public PetDAO() {
        conn = new Conexao().conectar();
        md = new ManipulaData();
        pDAO = new PessoaDAO();
    }
    
    public Pet salvar(Pet p){
        try{
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO pet(nome, raca, data_nascimento, cor, porte, idpessoa ) values(?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
            
      
            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getRaca());
            stmt.setDate(3, md.String2Date(p.getData_nascimento()));
            stmt.setString(4, p.getCor());
            stmt.setString(5, p.getPorte());
            stmt.setInt(6, p.getP().getIdpessoa());
            stmt.execute();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                p.setId(rs.getInt("idPet"));
            }
            else{
                p.setId(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return p;
    }
    
     public void editar(Pet p){
        
        try{
            PreparedStatement stmt = conn.prepareStatement("UPDATE pet SET nome = ?,raca = ?, data_nascimento = ?, cor = ?, porte = ?, idpessoa= ? where idpet = ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getRaca());
            stmt.setDate(3, md.String2Date(p.getData_nascimento()));
            stmt.setString(4, p.getCor());
            stmt.setString(5, p.getPorte());
            stmt.setInt(6, p.getP().getIdpessoa());
            stmt.setInt(7, p.getId());
            stmt.execute();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                p.setId(rs.getInt("idPet"));
            }
            else{
                p.setId(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }
     
    public int excluir(Pet p){
        int verif = 0;
        try{
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM pet where idPet= ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, p.getId());
            verif = stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                p.setId(rs.getInt("idpessoa"));
            }
            else{
                p.setId(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return verif;
    }
    
    public List<Pet>getPets(){
        List<Pet> lstP = new ArrayList();
        ResultSet rs;
        
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM pet", Statement.RETURN_GENERATED_KEYS);
            
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstP.add(getPet(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstP;
    }
    
    public List<Pet>getPets(String nome){
        List<Pet> lstP = new ArrayList();
        ResultSet rs;
        
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM pet where nome ILIKE ?", Statement.RETURN_GENERATED_KEYS);
            ppStmt.setString(1, nome + "%");
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstP.add(getPet(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstP;
    }
    
    public List<Pet> getPets(String nome, String dataInicio, String dataFim){
        List<Pet> lstP = new ArrayList<>();
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM pet where nome ILIKE ? and"
                + "data_nascimento BETEWEEN ? and ?");
            ppStmt.setString(1, nome+ "%");
            ppStmt.setDate(2, md.String2Date(dataInicio));
            ppStmt.setDate(3, md.String2Date(dataFim));
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstP.add(getPet(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstP;
    }
    
   public List<Pet> getPets(String dataInicio, String dataFim) {
    List<Pet> lstP = new ArrayList<>();
    ResultSet rs;
    try {
        PreparedStatement ppStmt = conn.prepareStatement(
            "SELECT * FROM pet WHERE data_nascimento BETWEEN ? AND ?"
        );
        ppStmt.setDate(1, md.String2Date(dataInicio));
        ppStmt.setDate(2, md.String2Date(dataFim));
        System.out.println("Data início SQL: " + md.String2Date(dataInicio));
        System.out.println("Data fim SQL: " + md.String2Date(dataFim));
        rs = ppStmt.executeQuery();
        while (rs.next()) {
            lstP.add(getPet(rs));
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    return lstP;
    }

    
    
    private Pet getPet(ResultSet rs) throws SQLException {
        
        Pet pet = new Pet();
        pet.setId(rs.getInt("idPet"));
        pet.setNome(rs.getString("nome"));
        pet.setRaca(rs.getString("raca"));
        pet.setData_nascimento(md.date2String(rs.getString("data_nascimento")));
        pet.setCor(rs.getString("cor"));
        pet.setPorte(rs.getString("Porte"));
        pet.setP(pDAO.getPessoas(rs.getInt("idpessoa")));
        return pet;
    }
}
