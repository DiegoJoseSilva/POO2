package BO;

import DAO.PetDAO;
import Objetos.Pet;
import java.util.List;

public class PetBO {
    
    PetDAO petDAO;

    public PetBO() {
       petDAO = new PetDAO();
    }
    
    public Pet salvar(Pet p){
        return petDAO.salvar(p);
    }
    
    public void editar(Pet p){
        petDAO.editar(p);
    }
    
    public int excluir(Pet p){
        return petDAO.excluir(p);
    }

    public List<Pet> getPets(){
        return petDAO.getPets();
    }
    
    public List<Pet> getPets(String nome){
        return petDAO.getPets(nome);
    }
    
    public List<Pet> getPets(String nome, String dataInicio, String dataFim){
        return petDAO.getPets(nome, dataInicio, dataFim);
    }
    
    public List<Pet> getPets(String dataInicio, String dataFim){
        return petDAO.getPets(dataInicio, dataFim);
    }
    
}
