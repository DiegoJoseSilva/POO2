package com.mycompany.prjpetshop;

public class PrjPetShop {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
