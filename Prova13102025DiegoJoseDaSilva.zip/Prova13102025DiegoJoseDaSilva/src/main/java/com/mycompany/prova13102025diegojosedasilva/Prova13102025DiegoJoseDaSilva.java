package com.mycompany.prova13102025diegojosedasilva;

public class Prova13102025DiegoJoseDaSilva {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
