package BO;

import DAO.ADAO;
import Objetos.A;
import java.util.List;

public class ABO {
    ADAO aDAO;

    public ABO() {
        aDAO = new ADAO();
    }

    public A salvar(A a) {
        return aDAO.salvar(a);
    }
    
    public List<A> getA(String nome){
       return aDAO.getA(nome);
    }
    //public void editar(A a) {
       // aDAO.editar(a);
    //}
}
