package DAO;

import Objetos.A;
import Objetos.B;
import Util.Conexao;
import Util.ManipulaData;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ADAO {
    private Connection conn;
    private ManipulaData mp;

    public ADAO() {
        conn = new Conexao().conectar();
        mp = new ManipulaData();
    }

    public A salvar(A a) {

        try {
            conn.setAutoCommit(false); // inicia transação manual

            // 1️⃣ Inserir o registro principal (A)
            PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO a (campo1, campo2, campo3) VALUES (?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS
            );
            stmt.setString(1, a.getCampo1());
            stmt.setString(2, a.getCampo2());
            stmt.setString(3, a.getCampo3());
            stmt.execute();

            // 2️⃣ Recuperar o ID gerado
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                a.setId(rs.getInt(1)); // ou "id_a" conforme sua tabela
            } else {
                a.setId(-1);
            }

            // 3️⃣ Inserir os registros filhos (B)
            List<B> listaB = a.getListaB();
            if (listaB != null && !listaB.isEmpty()) {
                PreparedStatement stmtB = conn.prepareStatement(
                    "INSERT INTO b (a_id, campo1, campo2, campo3) VALUES (?, ?, ?, ?)"
                );

                for (B b : listaB) {
                    stmtB.setInt(1, a.getId());
                    stmtB.setString(2, b.getCampo1());
                    stmtB.setString(3, b.getCampo2());
                    stmtB.setString(4, b.getCampo3());
                    stmtB.addBatch();
                }
                stmtB.executeBatch();
            }

            conn.commit(); // confirma tudo
        } 
        catch (SQLException ex) {
            try {
                conn.rollback(); // desfaz se der erro
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
            ex.printStackTrace();
        }

        return a; // retorna o objeto completo, já com id
    }
    
    public List<A> getA(String nome){
        List<A> lstP = new ArrayList<>();
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM A where campo1 ILIKE ?");
            ppStmt.setString(1, nome+ "%");
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstP.add(getA(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstP;
    }
    
    private A getA(ResultSet rs) throws SQLException {
        
        A p = new A();
        p.setId(rs.getInt("id"));
        p.setCampo1(rs.getString("campo1"));
        p.setCampo2(rs.getString("campo2"));
        p.setCampo3(rs.getString("campo3"));
        return p;
    }
}
