package BO;

public class PessoaBO {
    
}
