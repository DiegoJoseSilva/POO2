package BO;

public class ParticipantesBO {
    
}
