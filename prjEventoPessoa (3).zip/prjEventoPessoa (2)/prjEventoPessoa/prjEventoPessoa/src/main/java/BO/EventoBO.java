package BO;

public class EventoBO {
    
}
