package DAO;

import Objetos.Pessoa;
import Util.Conexao;
import Util.ManipulaData;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PessoaDAO {
    Connection conn;
    
    public PessoaDAO(Connection conn) {
        conn= new Conexao().conectar();
    }
    
    public Pessoa Salvar(Pessoa p){
        try{
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO pessoa(id_pessoa, nome, cpf, email) values(?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, p.getId_pessoa());
            stmt.setString(2, p.getNome());
            stmt.setString(3, p.getCpf());
            stmt.setString(4, p.getEmail());
            stmt.execute();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                p.setId_pessoa(rs.getInt("id_pessoa"));
            }
            else{
                p.setId_pessoa(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return p;
    }
    
    public void editar(Pessoa p){
        
        try{
            PreparedStatement stmt = conn.prepareStatement("UPDATE pessoa SET nome = ?, cpf = ?, email = ?" + "where id_pessoa= ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getCpf());
            stmt.setString(3, p.getEmail());
            stmt.execute();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                p.setId_pessoa(rs.getInt("id_pessoa"));
            }
            else{
                p.setId_pessoa(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }
    
     public int excluir(Pessoa p){
        int verif = 0;
        try{
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM pessoa where id_pessoa= ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, p.getId_pessoa());
            verif = stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                p.setId_pessoa(rs.getInt("idpessoa"));
            }
            else{
                p.setId_pessoa(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return verif;
    }
     
    public List<Pessoa>getPessoas(){
        List<Pessoa> lstP = new ArrayList();
        
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM pessoa", Statement.RETURN_GENERATED_KEYS);
            
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstP.add(getPessoa(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstP;
    }
    
    public List<Pessoa> getPessoas(Pessoa p){
        
        List<Pessoa> lstP = new ArrayList<>();
        ResultSet rs;
        
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM pessoa where nome ILIKE ?", Statement.RETURN_GENERATED_KEYS);
            ppStmt.setString(1, p.getNome()+ "%");
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstP.add(getPessoa(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstP;
    }

    private Pessoa getPessoa(ResultSet rs) throws SQLException {
        
        Pessoa p = new Pessoa();
        p.setId_pessoa(rs.getInt("id_pessoa"));
        p.setNome(rs.getString("nome"));
        p.setCpf(rs.getString("cpf"));
        p.setEmail(rs.getString("email"));
        return p;
    }   
}
