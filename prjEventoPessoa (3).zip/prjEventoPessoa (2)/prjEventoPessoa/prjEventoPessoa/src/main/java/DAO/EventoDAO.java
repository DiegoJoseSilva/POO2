package DAO;

import Objetos.Eventos;
import Util.Conexao;
import Util.ManipulaData;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EventoDAO {
    Connection conn;
    ManipulaData md;
    
    public EventoDAO(Connection conn, ManipulaData md) {
        conn= new Conexao().conectar();
        md = new ManipulaData();
    }
    
    public Eventos Salvar(Eventos e){
        try{
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO eventos(id_evento, nome, data) values(?,?,?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, e.getId_evento());
            stmt.setString(2, e.getNome());
            stmt.setDate(3, md.String2Date(e.getData()));
            stmt.execute();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                e.setId_evento(rs.getInt("id_evento"));
            }
            else{
                e.setId_evento(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
      
        return e;
    }
}
